const { Telegraf } = require("telegraf");

const bot = new Telegraf("8517357654:AAFjjNpfPn_U2Orm6X_U0hCVHscvNCQTD3c");
const ADMIN_CHAT_ID = 8262045291;

bot.start((ctx) => {
  ctx.reply(
    "🍔 Jo'ja FastFood — buyurtma berish uchun quyidagi tugmadan foydalaning 👇",
    {
      reply_markup: {
        keyboard: [
          [
            {
              text: "🍟 Buyurtma berish",
              web_app: { url: "https://jojafastfood.github.io/fastfood-miniapp/" }

            }
          ],
          [{ text: "📍 Manzil yuborish", request_location: true }]
        ],
        resize_keyboard: true
      }
    }
  );
});

bot.on("location", (ctx) => {
  const loc = ctx.message.location;
  bot.telegram.sendMessage(
    ADMIN_CHAT_ID,
    `📍 Yangi manzil:\nLatitude: ${loc.latitude}\nLongitude: ${loc.longitude}`
  );
  ctx.reply("Manzil muvaffaqiyatli yuborildi! 😊");
});

bot.on("web_app_data", (ctx) => {
  const data = JSON.parse(ctx.message.web_app_data.data);

  const text =
    `🍔 *Yangi buyurtma!*\n\n` +
    `👤 Ismi: ${data.name}\n` +
    `📞 Telefon: ${data.phone}\n` +
    `🍟 Taom: ${data.order}`;

  bot.telegram.sendMessage(ADMIN_CHAT_ID, text, { parse_mode: "Markdown" });
  ctx.reply("Buyurtmangiz qabul qilindi! 😊");
});

bot.launch();
console.log("Bot ishlayapti...");
